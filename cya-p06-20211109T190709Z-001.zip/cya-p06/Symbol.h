// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 6: DFA Simulator
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 08/11/2021
// Archivo: Declaración de la clase symbol. En principio, un elemento de 
// la clase symbol es un string, aunque con más escalabilidad.

#include <vector>
#include <string>
class Symbol {
  public: 
    Symbol() {};
    Symbol(const std::string& symbol) {symbol_ = symbol; };

    const std::string& GetSymbolString() const {return symbol_; };
    void SetSymbol(Symbol symbol) {symbol_ = symbol.GetSymbolString(); };
    void SetSymbol(const std::string& symbol) {symbol_ = symbol; };

    bool operator==(const Symbol& symbol) const;

  private:
    std::string symbol_;
};