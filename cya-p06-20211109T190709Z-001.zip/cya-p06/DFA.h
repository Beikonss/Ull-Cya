// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 6: DFA Simulator
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 08/11/2021
// Archivo: Definición de la clase DFA, que contiene
// el propio DFA y otras funciones auxiliares

#pragma once
#include "Chain.h"

class DFA {
 public:
  DFA() {};
  DFA(const Chain& initial_sequence) { initial_sequence_ = initial_sequence; };
  
  //Setters
  void SetInitialSequence(const Chain& initial_sequence) { initial_sequence_ = initial_sequence; };
  void SetMadeTransitions(const std::unordered_map<int, std::vector<std::pair<int, Symbol>>>& made_transitions) {made_transitions_ = made_transitions_; }
  void SetFinalState(const int& state) {final_state_ = state; };
  void SetIsAccepted(const bool& is_accepted) { is_accepted_ = is_accepted; };
  void SetAlphabet(const Alphabet& alphabet) { dfa_alphabet_ = alphabet; };
  void SetDeathStates(const std::vector<int>& states) { death_states_ = states; };
  void PushDeathState(const int& state) { death_states_.push_back(state); };

  //Getters
  const Chain& GetInitialSequence() const { return initial_sequence_; };
  const std::unordered_map<int, bool>& GetStatesWithAcceptationMap() const { return states_and_acceptation_; };
  const std::unordered_map<int, std::vector<std::pair<int, Symbol>>>& GetPossibleTransitionsMap() const { return possible_transitions_; };
  const std::unordered_map<int, int>& GetNumberOfStatesForTransitionsMap() const { return number_of_states_of_transition_; };
  const std::vector<std::pair<int, std::pair<int, Symbol>>>& GetMadeTransitions() const { return made_transitions_; };
  const int& GetInitialState() const { return initial_state_; };
  const int& GetNumberOfStates() const { return number_of_states_; };
  const int& GetFinalState() const { return final_state_; };
  const bool& IsAccepted() const { return is_accepted_; };
  const std::vector<int>& GetDeathStates() const { return death_states_; };
  Alphabet GetDfaAlphabet() { return dfa_alphabet_; };
  
  //Aux functions
  void EraseDuplicates(std::vector<std::string>& str_vec);
  void CleanMadeTransitions();
  void ConstructDFA(const std::string& string_from_file, const int& line_index);
  void ConstructMadeTransitions(const Chain& chain);
  bool IsAcceptationState(const int& state);
  bool IsSymbolFromAlphabet(const Symbol& symbol);
  void SetDeathStates(const int& number_of_lines);
  bool IsGoodDFA(const int& line_index);

  //Print output functions
  void PrintAllTransitions(std::ofstream& file, std::string filename);
  void PrintChainsWithAcceptation(std::ofstream& file, std::string filename);
  void PrintDeathStates(std::ofstream& file, std::string filename);

 private:
  Chain initial_sequence_;
  Alphabet dfa_alphabet_;

  int initial_state_ = 0;
  int number_of_states_ = (int)HUGE_VAL;
  int final_state_ = (int)HUGE_VAL;

  bool is_accepted_ = false;

  std::vector<int> death_states_{};
  std::unordered_map<int, bool> states_and_acceptation_;
  std::unordered_map<int, std::vector<std::pair<int, Symbol>>> possible_transitions_;
  std::unordered_map<int, int> number_of_states_of_transition_;

  std::vector<std::pair<int, std::pair<int, Symbol>>> made_transitions_;  
};