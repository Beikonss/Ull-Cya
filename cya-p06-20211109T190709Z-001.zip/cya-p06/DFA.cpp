// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 6: DFA Simulator
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 08/11/2021
// Archivo: Implementación de la clase DFA, que contiene
// el propio DFA y otras funciones auxiliares

#include "DFA.h"

bool SortBySize(const std::pair<Chain, int>& sequences, const std::pair<Chain, int> & self_sequences) {
  return (sequences.first.GetSymbolVector().size() < self_sequences.first.GetSymbolVector().size());
}

std::vector<Symbol> FromPairVecToSymbolVec(const std::vector<std::pair<int, Symbol>>& pair_vec) {
  std::vector<Symbol> symbol_vec{};
  for (int i = 0; i < pair_vec.size(); i++) {
    symbol_vec.push_back(pair_vec[i].second);
  }
  return symbol_vec;
}

std::string EliminateSpaces(const std::string& input_from_file) {
  std::string without_spaces = "";
  for (int i = 0; i < input_from_file.length(); i++) {
    if (input_from_file[i] != ' ') {
      without_spaces += input_from_file[i];
    }
  }
  return without_spaces;
}

int ctoi(const char& character) {
  int to_return = character - '0';
  return to_return;
}

bool DFA::IsSymbolFromAlphabet(const Symbol& symbol) {
  auto dfa_alphabet = GetDfaAlphabet();
  for (auto dfa_symbol : dfa_alphabet.GetAlphabet()) {
    if (symbol == dfa_symbol) {
      return true;
    }
  }
  return false;
}

// This function build the DFA from the input file. 
// The formatting of the file has to be strict
void DFA::ConstructDFA(const std::string& input_from_file, const int& line_index) {
  std::string without_spaces = EliminateSpaces(input_from_file);
  Symbol transition_symbol;
  int transited_state;
  std::pair<int,Symbol> starting_to_transited;
  if (line_index == 1) {
    number_of_states_ = std::stoi(without_spaces);
  }
  if (line_index == 2) {
    initial_state_ = std::stoi(without_spaces);
    if (without_spaces.length() > 1) {
      std::cout << "Only 1 initial state is accepted. DFA not valid" << std::endl;
      exit(EXIT_FAILURE);
    }
  }
  int analizing_state = ctoi(without_spaces[0]);
  number_of_states_of_transition_[analizing_state] = ctoi(without_spaces[2]);
  states_and_acceptation_[analizing_state] = ctoi(without_spaces[1]);

  if ( (without_spaces.length() > ((ctoi(without_spaces[2]) * 2) + 3) ) ||
     ( without_spaces.length() < ((ctoi(without_spaces[2]) * 2) + 3 ) ) && line_index > 2) {
    std::cout << "[Line " << line_index << "] " << "DFA not valid. Number of transitions don't match." << std::endl << "Specified number is: " <<
    ctoi(without_spaces[2]) << std::endl << "Number of transitions is: " << (without_spaces.length() - 3)/2 << std::endl;
    exit(EXIT_FAILURE);
  }
  if (without_spaces.length() % 2 == 0) {
    std::cout << "[Line " << line_index << "] " << "DFA not valid. Transition not specified." << std::endl;
    exit(EXIT_FAILURE);
  }

  for (int i = 3; i < without_spaces.size(); i++) {
    if ( (i+1) % 2 == 0) {
      std::string symbol(1, without_spaces[i]);
      transition_symbol.SetSymbol(symbol);
      dfa_alphabet_.PushSymbol(transition_symbol);
      transited_state = ctoi(without_spaces[i+1]);
      starting_to_transited.first = transited_state;
      starting_to_transited.second = transition_symbol;
      possible_transitions_[analizing_state].push_back(starting_to_transited);
    }
  }
}

void DFA::SetDeathStates(const int& number_of_lines) {
  int transitions = 0;
  int starting_state = 0;
  auto possible_transitions = GetPossibleTransitionsMap();

  for (auto transition : possible_transitions) {
    starting_state = transition.second[0].first;
    for (int i = 0; i < transition.second.size(); i++) {
      if (transition.second[i].first == starting_state) {
        transitions ++;
      }
    }
    if (transitions == number_of_states_of_transition_[transition.first]
        && !IsAcceptationState(transition.first)) {
      PushDeathState(transition.first);
    }
    transitions = 0;
  }
}

bool DFA::IsAcceptationState(const int& state_to_check) {
  auto states = GetStatesWithAcceptationMap();
  if (states[state_to_check] == 1) {
    return true;
  }
  return false;
}

// This function is used to map all transitions made by the chain
// in the DFA member made_transtions
// For each transition includes: starting state, final state and transition symbol.
// We check for the final state and if it's accepted we set the chain to accepted.
void DFA::ConstructMadeTransitions(const Chain& chain) {
  const int& initial_state = GetInitialState();
  int current_state = initial_state;
  std::pair<int, std::pair<int, Symbol>> transitions_pair;
  std::vector<Symbol> chain_symbol_vec = chain.GetSymbolVector();
  auto acceptation_states = GetStatesWithAcceptationMap();
  auto possible_transitions = GetPossibleTransitionsMap();

  for (int i = 0; i < chain_symbol_vec.size(); i++) {
    // If a symbol doesn't belong to the alphabet we set the final state to
    // infinity and reject it directly.
    if (!IsSymbolFromAlphabet(chain_symbol_vec[i])) {
      SetFinalState((int)HUGE_VAL);
      SetIsAccepted(false);
      return;
    }
    auto current_state_transitions = possible_transitions[current_state];
    for (int j = 0; j < current_state_transitions.size(); j++) {
      if (current_state_transitions[j].second == chain_symbol_vec[i]) {
        transitions_pair.first = current_state;
        current_state = current_state_transitions[j].first;
        transitions_pair.second.first = current_state;
        transitions_pair.second.second = chain_symbol_vec[i];
        made_transitions_.push_back(transitions_pair);
        break;
      }
    }
  }
  SetFinalState(current_state);
  SetIsAccepted(IsAcceptationState(current_state));
}

void DFA::CleanMadeTransitions() {
  made_transitions_.clear();
}

// Outputs to file the chain and its state (accepte/rejected)
void DFA::PrintChainsWithAcceptation(std::ofstream& file, std::string filename) {
  file.open(filename, std::ofstream::app);
  auto initial_chain = GetInitialSequence();
  if (IsAccepted()) {
    file << initial_chain.FromChainToStr() << "\t" << "-- " << "Accepted" << std::endl;
  }
  else {
    if (GetFinalState() == (int)HUGE_VAL) {
      file << initial_chain.FromChainToStr() << "\t" << "-- " << "Rejected: 1 or more symbols don't belong to the alphabet" << std::endl;
    }
    else {
      file << initial_chain.FromChainToStr() << "\t" << "-- " << "Rejected" << std::endl;
    }
  }
  file.close();
}

bool DFA::IsGoodDFA(const int& line_index) {
  int transitions_with_same_symbol = 0;
  Symbol comparing_symbol;
  auto possible_transitions = GetPossibleTransitionsMap();
  int i = 0;
  for (auto transition : possible_transitions) {
    auto new_symbol_vec = FromPairVecToSymbolVec(transition.second);
    for (int i = 0; i < new_symbol_vec.size(); i++) {
      if (std::count(new_symbol_vec.begin(), new_symbol_vec.end(), new_symbol_vec[i]) > 1) {
        std::cout << "Line [" << line_index << "]: " << "1 or more transitions found with the same symbol. DFA not valid" << std::endl;
        return false; 
      }
    }
  }
  return true;
}

//Outputs to file all the transitions made by the chain for the given DFA
void DFA::PrintAllTransitions(std::ofstream& file, std::string filename) {
  file.open(filename, std::ofstream::app);
  for (auto transitions : made_transitions_) {
    file << transitions.first << " -> " << transitions.second.first << " with: " << transitions.second.second.GetSymbolString() << std::endl;
  }
  file << std::endl;
  file.close();
}

void DFA::PrintDeathStates(std::ofstream& file, std::string filename) {
  file.open(filename, std::ofstream::app);
  file << "Death states: ";
  for (auto death_state : GetDeathStates()) {
    file << death_state << ", ";
  }
  file << std::endl;
  file.close();
}



