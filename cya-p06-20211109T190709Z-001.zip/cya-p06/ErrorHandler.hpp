// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 6: DFA Simulator
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 08/11/2021
// Archivo: Errorhandler.(For input and help msgs)
#pragma once
struct ErrorHandler {
  static void BadConsoleInputMsg();
  static void NoInputFileMsg();
  static void HelpMessage();
};

void ErrorHandler::BadConsoleInputMsg() {
  std::cout << "Usage: ./p06_dfa_simulator input.dfa input.txt output.txt. Try ’dfa_simulation --help’ for more information." << std::endl;
}

void ErrorHandler::NoInputFileMsg() {
    std::cout << "Some of the inputs files were missing. Try the following format: ./p06_dfa_simulator input.dfa input.txt output.txt" << std::endl;
}

void ErrorHandler::HelpMessage() {
  std::cout << "This is a program that generates a DFA based on the .dfa file given, and analizes all the chains given in the file input.txt.\nUsage: ./p06_dfa_simulator input.dfa input.txt output.txt"  << std::endl;
}

