// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 6: DFA Simulator
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 08/11/2021
// Archivo: Header de la clase alfabeto, declaración de clase.
// El alfabeto se usa principalmente para comprobar la validez
// de la cadena de entrada.

#pragma once
#include "Symbol.h"
#include "iostream"
#include "algorithm"

class Alphabet {
  public:
    Alphabet() {};
    Alphabet(const std::vector<Symbol> alphabet) {alphabet_ = alphabet; };
    Alphabet(const std::string& alphabet);

    const std::vector<Symbol> GetAlphabet() const {return alphabet_; };
    void SetAlphabet(const std::vector<Symbol>& alphabet) {alphabet_ = alphabet; };
    void PushSymbol(const Symbol& symbol) { alphabet_.push_back(symbol); };
    void EraseDuplicates();
    std::vector<std::string> FromSymbolVecToStringVec(const std::vector<Symbol>& symbol_vec);
    std::vector<Symbol> FromStringVecToSymbolVec(const std::vector<std::string>& string_vec);

  private:
    std::vector<Symbol> alphabet_ {};
};