// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 6: DFA Simulator
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 08/11/2021
// Archivo: Alphabet implementation

#include "Alphabet.h"

Alphabet::Alphabet(const std::string& alphabet) {
  Symbol aux;
  for (int i = 0; i < alphabet.length(); i++) {
    std::string char_to_str(1, alphabet[i]);
    aux.SetSymbol(char_to_str);
    alphabet_.push_back(aux);
  }
}

std::vector<std::string> Alphabet::FromSymbolVecToStringVec(const std::vector<Symbol>& symbol_vec) {
  std::vector<std::string> vector_to_return {};
  for (int i = 0; i < symbol_vec.size(); i++) {
    std::string symbol_string(symbol_vec[i].GetSymbolString());
    vector_to_return.push_back(symbol_string);
  }
  return vector_to_return;
}

std::vector<Symbol> Alphabet::FromStringVecToSymbolVec(const std::vector<std::string>& string_vec) {
  Symbol aux_symbol;
  std::vector<Symbol> vector_to_return{};
  for (int i = 0; i < string_vec.size(); i++) {
    aux_symbol.SetSymbol(string_vec[i]);
    vector_to_return.push_back(aux_symbol);
  }
  return vector_to_return;
}


void Alphabet::EraseDuplicates() {
  auto str_vec = FromSymbolVecToStringVec(GetAlphabet());
  std::sort(str_vec.begin(), str_vec.end());
  str_vec.erase(std::unique(str_vec.begin(), str_vec.end()), str_vec.end());
  auto new_alphabet = FromStringVecToSymbolVec(str_vec);
  SetAlphabet(new_alphabet);
}

