// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 6: DFA Simulator
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 02/11/2021
// Archivo: Cliente

#include "DFA.h"
#include "ErrorHandler.hpp"
#include <bits/stdc++.h>

int main(int argc, char* argv[]) {
  if (argc == 2) {
    std::string help_check = argv[1];
    if (help_check == "--help") {
      ErrorHandler::HelpMessage();
      return 0;
    }
  }
  if (argc == 4) {
    std::string output_file = argv[3];
    std::ifstream file(argv[1]);
    std::ofstream outputStream;
    if (!file){
      ErrorHandler::NoInputFileMsg();
      return 0;
    }
    if (argv[2] == ""){
      ErrorHandler::NoInputFileMsg();
      return 0;
    }

    std::ifstream chains(argv[2]);
    std::string line; 
    
    DFA dfa_test;
    int line_index = 1;
    if (file.is_open()) {
      while (getline(file,line)) {
        dfa_test.ConstructDFA(line, line_index);
        if (!dfa_test.IsGoodDFA(line_index)) {
          return 0;
        }
        line_index++;
      }
    }
    Alphabet dfa_alphabet = dfa_test.GetDfaAlphabet();
    dfa_alphabet.EraseDuplicates();
    dfa_test.SetAlphabet(dfa_alphabet);
    dfa_test.SetDeathStates(line_index);
    dfa_test.PrintDeathStates(outputStream, output_file);
    line_index = 1;
    // for (auto tal : dfa_test.GetPossibleTransitionsMap()) {
    //   for (auto talcual : tal.second) {
    //     std::cout << talcual.first << " -> " << talcual.second.GetSymbolString() << std::endl;
    //   }
    // }
    if (chains.is_open()) {
      while (getline(chains,line)) {
        Chain test(line);
        dfa_test.SetInitialSequence(test);
        dfa_test.ConstructMadeTransitions(test);
        line_index++;
        dfa_test.PrintChainsWithAcceptation(outputStream, output_file);
        dfa_test.PrintAllTransitions(outputStream, output_file);
        dfa_test.CleanMadeTransitions();
      }
    }
  }
  else {
    ErrorHandler::BadConsoleInputMsg();
  }
  return 0;
}