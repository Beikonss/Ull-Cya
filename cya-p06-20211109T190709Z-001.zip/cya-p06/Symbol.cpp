#include "Symbol.h"
bool Symbol::operator==(const Symbol& symbol) const {
  if (GetSymbolString() == symbol.GetSymbolString()) {
    return true;
  }
  return false;
}