#pragma once
#include "Includes.h"
#include "Symbol.h"

class Alphabet {
  public:
    Alphabet(){};
    Alphabet(const std::string& fileInput);
    Alphabet(std::vector<Symbol> alphabet) {alphabet_ = alphabet; };
    ~Alphabet(){};

    const std::vector<Symbol>& GetAlphabet() const {return alphabet_; };
    void SetAlphabet(const std::vector<Symbol>& alphabet) {alphabet_ = alphabet; };
    void FilterChainFromAlphabet(const std::string& fileInput);

    friend std::ostream &operator<<(std::ostream &output, Alphabet alphabet ) {
      auto symbolAlphabet = alphabet.GetAlphabet();
      for (auto& symbol : symbolAlphabet) {
        output << symbol.GetSymbol();
      }
      return output;
    }
    
    friend std::istream &operator>>(std::istream &input, Alphabet alphabet ) {
      std::string stringInput;
      input >> stringInput;
      alphabet.FilterChainFromAlphabet(stringInput);
      return input;
    }

  private:
    std::vector<Symbol> alphabet_{};
};