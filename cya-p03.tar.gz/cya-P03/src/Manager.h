#pragma once
#include "Includes.h"
#include "Alphabet.h"
#include "Chain.h"

class Manager {
  public:
    Manager(){};
    // String(std::string chain, std::vector<std::string> alphabet);
    Manager(const std::string& fileInput);
    Manager(Chain chain, Alphabet alphabet);
    Manager(std::vector<Symbol> chain);

    //Getters 
    const int GetLength()  {return chain_.GetSymbolsChain().size(); };
    const Chain GetChain() const {return chain_; };
    const Alphabet GetAlphabet() const {return alphabet_; };

    //Setters
    void SetChain(const std::vector<std::string>& textChain);
    void SetAlphabet(const std::vector<std::string>& alphabet);
    void SetChain(std::vector<Symbol> chain) {chain_.SetChain(chain); };
    void SetAlphabet(std::vector<Symbol> alphabet) {alphabet_ = alphabet; };
    void SetChain(Chain chain) {chain_ = chain; };
    void SetAlphabet(Alphabet alphabet) {alphabet_ = alphabet; };

    //Asked functions
    void PrintLength(std::ofstream& file, std::string filename);
    void PrintReversedChain(std::ofstream& file, std::string filename);
    void PrintPrefixes(std::ofstream& file, std::string filename);
    void PrintSufixes(std::ofstream& file, std::string filename);
    void PrintSubChains(std::ofstream& file, std::string filename);
    void PrintConcatenation(std::ofstream& file, std::string filename, Chain secondChain);
    void PrintPower(std::ofstream& file, std::string filename, Chain secondChain, int power);
    const bool PrintComparationEqual(std::ofstream& file, std::string filename, const Chain& secondChain) const;
    const bool PrintComparation1Sub2(std::ofstream& file, std::string filename, const Chain& secondChain) const;
    const bool PrintComparation2Sub1(std::ofstream& file, std::string filename, const Chain& secondChain) const;
    const void PrintComparationNotEqual(std::ofstream& file, std::string filename, const Chain& secondChain) const;
    std::vector<std::string> GetAllSubchains(std::string str);
    void GetAlphabetFromChain(const int lineIndex);
    
    //Auxiliar functions
    std::vector<std::string> GetPrefixes();
    std::vector<std::string> GetSufixes();
    std::vector<std::string> GetSubChains(const std::string& toGetSubchain);
    std::vector<std::string> FromSymbolVecToStringVec(std::vector<Symbol> symbolVec);
    Chain StringToChain(std::string str);
    bool IsIndivisibleSymbolFoundDividedInChain(std::string stringToCheck = "");
    bool ChainCharacterDoesntMatchToAlphabet(const int& line);
    std::vector<Chain> FromStringVectorToChainVector(std::vector<std::string> stringVec);
    void EraseDuplicates(std::vector<std::string>& strVec);
    void ReverseChain();
    void CleanPermutationsVector();

  private:
    Alphabet alphabet_;
    Chain chain_;
};

static std::vector<std::string> allPermutations{};
static std::vector<Chain> allSubchains{};
static std::vector<Manager> allLinesCache{};