#pragma once
#include <iostream>
#include <vector>
#include <stdlib.h>
#include <math.h>
#include <bits/stdc++.h>
#include <fstream>
#include <set>

#define Blue  "\x1B[34m"
#define Green  "\x1B[32m"
#define Red  "\x1B[31m"
#define White  "\x1B[37m"