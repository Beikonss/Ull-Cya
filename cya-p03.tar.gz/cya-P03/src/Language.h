#include "Includes.h"
#include "Chain.h"

class Language {
  public:
    Language(){};
    Language(const Chain& chain) {chain_ = chain; };
    Language(const Language& language) {chainSet_ = language.chainSet_; };

    std::set<Chain> GetLanguageSet() const {return chainSet_; } ;
    const Chain GetChain() const {return chain_; };
    void SetLanguage(const Chain& chain) {chain_ = chain; };
    void SetLanguageSet(const std::set<Chain>& chainSet) {chainSet_ = chainSet; };

    Chain GetIntersection(const Language& language2);
    Language GetPotency(const int& potency);

    const bool operator +(Language secondLanguage);

  private:
    Chain chain_;
    std::set<Chain> chainSet_;

};