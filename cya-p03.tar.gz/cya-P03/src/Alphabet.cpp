#include "Alphabet.h"

void Alphabet::FilterChainFromAlphabet(const std::string& input) {
  Symbol symbol;
  std::vector<Symbol> chainAndAlphabet{};
  std::vector<Symbol> alphabet{};
  std::vector<Symbol> chainFinal{};
  std::string chain = "";
  std::string filteringString = "";
  bool hasAlphabetDefined = false;

 //Case no alphabet defined
  //Regular case
  for (int i = 0; i < input.length(); i++){
    //No space so we increase the string
    if (input[i] != ' '){
      filteringString += input[i];
    }
    else{
      symbol.SetSymbol(filteringString);
      chainAndAlphabet.push_back(symbol);
      //If we find a space, then we empty the string
      filteringString = "";
    }
  }
  if (filteringString != ""){
    symbol.SetSymbol(filteringString);
    chainAndAlphabet.push_back(symbol);
  }
  //We make sure that this is not the chain so we push back the alphabet
  chain = chainAndAlphabet[chainAndAlphabet.size() -1].GetSymbol();
  for (int i = 0; i < chain.length(); i++) {
    std::string s(1, chain[i]);
    symbol.SetSymbol(s);
    chainFinal.push_back(symbol);
  }

  for (int i = 0; i < chainAndAlphabet.size(); i++) {
    if (chainAndAlphabet[i].GetSymbol() != chain
    && chainAndAlphabet[i].GetSymbol() != "") {
      alphabet.push_back(chainAndAlphabet[i]);
    }
  }
  SetAlphabet(alphabet);
}

Alphabet::Alphabet(const std::string& fileInput) {
  FilterChainFromAlphabet(fileInput);
}
