#pragma once
#include "Includes.h"
#include "Symbol.h"

class Chain {
  public:
    Chain(){};
    Chain(std::vector<Symbol> chain) {chain_ = chain; };
    Chain(const std::string& fileInput);
    // Chain(const Chain& chain) {chain_ = chain.chain_;};

    ~Chain(){};

    const std::vector<Symbol>& GetSymbolsChain() const {return chain_; };
    std::set<std::string> GetChainSet() {return chainSet_; };
    void SetChain(std::vector<Symbol> chain) {chain_ = chain; };
    void SetChainSet(std::set<std::string> chainSet) {chainSet_ = chainSet; };
    void FilterChainFromAlphabet(const std::string& fileInput);
    std::vector<Chain> FromStringVecToChainVec(const std::vector<std::string>& stringVec) const;
    const std::string ConvertChainToString() const;
    std::set<std::string> FromSymbolVecToStringSet(const std::vector<Symbol>& symbolVec) const;

    const bool operator == (const Chain&) const;
    const bool operator != (const Chain&) const;
    const bool operator > (const Chain&) const;
    const bool operator < (const Chain&) const;
    const Chain operator *(const Chain&) const;
    const Chain operator ^(int n) const;
    const Chain operator +(const Chain&) const;

    friend std::ostream &operator<<(std::ostream &output, Chain chain ) {
      output << chain.ConvertChainToString();
      return output;
    }
    
    friend std::istream &operator>>(std::istream &input, Chain chain ) {
      std::string stringInput;
      input >> stringInput;
      chain.FilterChainFromAlphabet(stringInput);
      return input;
    }

  private:
    std::vector<Symbol> chain_{};
    std::set<std::string> chainSet_;
};

