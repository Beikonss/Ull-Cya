#include "Symbol.h"

bool Symbol::IsValid(Symbol symbol) {
  if (symbol.GetSymbol() == "&") {
    return false;
  }
  return true;
}

const bool Symbol::operator ==(const Symbol& symbolToCompare) const {
  if (GetSymbol() == symbolToCompare.GetSymbol()) {
    return true;
  }
  return false;
}

const bool Symbol::operator != (const Symbol& symbolToCompare) const {
  if (GetSymbol() == symbolToCompare.GetSymbol()) {
    return false;
  }
  return true;
}

std::ostream& operator<<(std::ostream& os, Symbol symbol) {
  os << symbol.GetSymbol();
  return os;
}