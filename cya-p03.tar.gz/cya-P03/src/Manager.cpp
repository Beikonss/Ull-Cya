#include "Manager.h"

Manager::Manager(const std::string& fileInput) {
  Alphabet alphabet(fileInput);
  Chain chain(fileInput);
  SetAlphabet(alphabet);
  SetChain(chain);
}

Manager::Manager(std::vector<Symbol> chain) {
  SetChain(chain);
}

void Manager::EraseDuplicates(std::vector<std::string>& strVec){
  for (int i = 0; i < strVec.size(); ++i) {
    for (int j = i + 1; j < strVec.size(); ) { 
        if (strVec[i] == strVec[j]) {
            strVec.erase(strVec.begin() + j);
        }
        else ++j;
    }
  }
}

void Manager::SetChain(const std::vector<std::string>& textChain) {
  Symbol symbol;
  std::vector<Symbol> aux{}; 
  for (int i = 0; i < textChain.size(); i++) {
    symbol.SetSymbol(textChain[i]);
    aux.push_back(symbol);
  }
  SetChain(aux);
}

void Manager::SetAlphabet(const std::vector<std::string>& alphabet) {
  Symbol symbol;
  std::vector<Symbol> aux{}; 
  for (int i = 0; i < alphabet.size(); i++) {
    symbol.SetSymbol(alphabet[i]);
    aux.push_back(symbol);
  }
  SetAlphabet(aux);
}

std::vector<std::string> Manager::FromSymbolVecToStringVec(std::vector<Symbol> symbolVec) {
  std::vector<std::string> vectorToReturn {};
  for (int i = 0; i < symbolVec.size(); i++) {
    vectorToReturn.push_back(symbolVec[i].GetSymbol());
  }
  return vectorToReturn;
}

bool IsCharFoundInString(std::string string, char character) {
  for (int p = 0; p < string.length(); p++) {
    if (string[p] == character) {
        return true;
    }
  }
  return false;
}

bool Manager::IsIndivisibleSymbolFoundDividedInChain(std::string stringToCheck){
  if (stringToCheck == "") {
    stringToCheck = chain_.ConvertChainToString();
  }

  std::vector<std::string> alphabet{FromSymbolVecToStringVec(alphabet_.GetAlphabet())};
  for (int k = 0; k < stringToCheck.length(); k++){
    for (int i = 0; i < alphabet.size(); i++){
      for (int j = 0; j < alphabet[i].length(); j++){
        if (alphabet[i].length() > 1){
        //   std::cout << "Alphabet ij: " << alphabet[i][j] << std::endl;
        //   std::cout << "Alphabet i j + 1: " << alphabet[i][j+1] << std::endl;
        //   std::cout << "Chain k " << stringToCheck[k] << std::endl;
        //   std::cout << "Chain k+1 " << stringToCheck[k+1] << std::endl;
          if (alphabet[i][j] == stringToCheck[k] &&
          alphabet[i][j+1] != stringToCheck[k+1]) {
            for (int l = 0; l < alphabet.size(); l++) {
              if (IsCharFoundInString(alphabet[l], stringToCheck[k]) == false
              && IsCharFoundInString(alphabet[l], stringToCheck[k+1]) == false) {
                return true;
              } 
            }
          }
        } 
      }
    }
  }
  return false;
}

void Manager::GetAlphabetFromChain(const int lineIndex){
  if (alphabet_.GetAlphabet().size() == 0){
    std::vector<Symbol> chain {chain_.GetSymbolsChain()};
    printf(Green);
    std::cout << std::endl << "Warning: " << "line " << lineIndex << " Alphabet not introduced --> Auto generating alphabet..." << std::endl;
    std::vector<Symbol> newAlphabet{};
    std::vector<std::string> aux{};
    Symbol symbol;
    for (int i = 0; i < chain.size(); i++){
      aux.push_back(chain[i].GetSymbol());
    }
    EraseDuplicates(aux);
    for (int i = 0; i < aux.size(); i++){
      symbol.SetSymbol(aux[i]);
      newAlphabet.push_back(symbol);
    }
    SetAlphabet(newAlphabet);
    std::cout << "Alphabet generated from chain" << ". . . The alphabet generated is: " << '{';
    for (int i = 0; i< alphabet_.GetAlphabet().size(); i++){
      std::cout << alphabet_.GetAlphabet()[i].GetSymbol() << ',';
    }
    std::cout << '}' << std::endl;
  }
}

std::vector<std::string> Manager::GetPrefixes() {
  std::vector<std::string> chainToStringVec = {FromSymbolVecToStringVec(chain_.GetSymbolsChain())};
  std::vector<std::string> prefixesVecFinal{};
  std::string prefixString = "";
  for (int i = 0; i < chainToStringVec.size(); i++) {
    prefixString += chainToStringVec[i];
    prefixesVecFinal.push_back(prefixString);
  }
  return prefixesVecFinal;
}

std::vector<std::string> Manager::GetSufixes() {
  std::vector<std::string> chainToStringVec = {FromSymbolVecToStringVec(chain_.GetSymbolsChain())};
  std::vector<std::string> sufixesVecFinal{};
  std::string sufixString = "";
  for (int i = chainToStringVec.size()-1; i >= 0; i--) {
    sufixString += chainToStringVec[i];
    sufixesVecFinal.push_back(sufixString);
  }
  for (int i = 0; i < sufixesVecFinal.size(); i++) {
    std::reverse(sufixesVecFinal[i].begin(), sufixesVecFinal[i].end());
  }
  return sufixesVecFinal;
}

std::vector<std::string> Manager::GetAllSubchains( std::string str) {
  std::string s = str;
  std::sort(s.begin(), s.end()); // to know when you've been through all permutations
  std::vector<std::string> v; // v.reserve(boost::math::factorial(s.size());
  do {
    v.push_back(s); // or process in-place
  } while (std::next_permutation(s.begin(), s.end()));
  return v;
}

void Manager::PrintSubChains(std::ofstream& file, std::string filename) {
  //SubChains from the whole chain
  std::string chain = chain_.ConvertChainToString();
  std::vector<std::string> fullWordSubchains = GetAllSubchains(chain);
  file.open(filename, std::ofstream::app);
  //SubChains from prefixes / Sufixes
  std::vector<std::string> preFixes{GetPrefixes()};
  for (int i = 0; i < preFixes.size(); i++) {
    std::vector<std::string> prefixesSubchains = GetAllSubchains(preFixes[i]);
    fullWordSubchains.insert(fullWordSubchains.end(), prefixesSubchains.begin(), prefixesSubchains.end());
  }
  EraseDuplicates(fullWordSubchains);
  for (int j = 0; j < fullWordSubchains.size(); j++){
    if (!IsIndivisibleSymbolFoundDividedInChain(fullWordSubchains[j])) {
      file << fullWordSubchains[j] << std::endl;
    }
  }
//   std::cout << allPermutations.size();
  file.close();
}

std::vector<std::string> Manager::GetSubChains(const std::string& toGetSubchain) {
  //SubChains from the whole chain
  std::string chain = toGetSubchain;
  GetAllSubchains(chain);
  //SubChains from prefixes / Sufixes
  std::vector<std::string> fullWordSubchains = GetAllSubchains(chain);
  std::vector<std::string> preFixes{GetPrefixes()};
  for (int i = 0; i < preFixes.size(); i++) {
    std::vector<std::string> prefixesSubchains = GetAllSubchains(preFixes[i]);
    fullWordSubchains.insert(fullWordSubchains.end(), prefixesSubchains.begin(), prefixesSubchains.end());
  }
  EraseDuplicates(fullWordSubchains);
  for (int j = 0; j < fullWordSubchains.size(); j++){
    if (IsIndivisibleSymbolFoundDividedInChain(fullWordSubchains[j])) {
      fullWordSubchains.erase(fullWordSubchains.begin() + j);
    }
  }
  return fullWordSubchains;
}

std::vector<Chain> Manager::FromStringVectorToChainVector(std::vector<std::string> strVec) {
  std::vector<Chain> chainVecToReturn;
  std::vector<Symbol> auxSymbolVec;
  Chain auxChain;
  Symbol auxSymbol;
  for (int i = 0; i < strVec.size(); i++) {
    for (int j = 0; j < strVec[i].length(); j++) {
      std::string s(1, strVec[i][j]);
      auxSymbol.SetSymbol(s);
      auxSymbolVec.push_back(auxSymbol);
    }
    chainVecToReturn.push_back(auxSymbolVec);
    auxSymbolVec.clear();  
  }
  return chainVecToReturn;
}


void Manager::PrintLength(std::ofstream& file, std::string filename) {
  file.open(filename, std::ofstream::app);
  file << GetLength() << std::endl;
  file.close();
}

void Manager::PrintReversedChain(std::ofstream& file, std::string filename) {
  std::vector<std::string> reversedChain { FromSymbolVecToStringVec(chain_.GetSymbolsChain()) };
  file.open(filename, std::ofstream::app);
  for (int i = reversedChain.size() -1; i >= 0; i--) {
    file << reversedChain[i];
  }
  file << std::endl;
  file.close();
}

void Manager::PrintPrefixes(std::ofstream& file, std::string filename) {
  std::vector<std::string> toPrint{GetPrefixes()};
  file.open(filename, std::ofstream::app);
  file << "{" << "&, ";
  for (int i = 0; i < toPrint.size(); i++) {
    file << toPrint[i] << ", ";
  }
  file << "}";
  file << std::endl;
  file.close();
}

void Manager::PrintSufixes(std::ofstream& file, std::string filename) {
  std::vector<std::string> toPrint{GetSufixes()};
  file.open(filename, std::ofstream::app);
  file << "{" << "&, ";
  for (int i = 0; i < toPrint.size(); i++) {
    file << toPrint[i] << ", ";
  }
  file << "}";
  file << std::endl;
  file.close();
}

void Manager::PrintConcatenation(std::ofstream& file, std::string filename, Chain secondChain) {
  file.open(filename, std::ofstream::app);
  Chain newChainSet = (GetChain() * secondChain);
  file << newChainSet.ConvertChainToString();
  for (const auto& setMember : newChainSet.GetChainSet()) {
    
  }
  file << std::endl;
  file.close();
}

void Manager::PrintPower(std::ofstream& file, std::string filename, Chain secondChain, int power) {
  file.open(filename, std::ofstream::app);
  Chain newChainSet = (GetChain() ^ power);
  file << newChainSet.ConvertChainToString();
  for (const auto& setMember : newChainSet.GetChainSet()) {
    
  }
  file << std::endl;
  file.close();
}

const bool Manager::PrintComparationEqual(std::ofstream& file, std::string filename, const Chain& secondChain) const {
  file.open(filename, std::ofstream::app);
  if (GetChain() == secondChain) {
    file << GetChain().ConvertChainToString() << " == " << secondChain.ConvertChainToString();
    file << std::endl;
    file.close();
    return true;
  }
  return false;
}

const void Manager::PrintComparationNotEqual(std::ofstream& file, std::string filename, const Chain& secondChain) const {
  if (GetChain() != secondChain) {
    file << GetChain().ConvertChainToString() << " != " << secondChain.ConvertChainToString();
    file << std::endl;
    file.close();
  }
}

const bool Manager::PrintComparation1Sub2(std::ofstream& file, std::string filename, const Chain& secondChain) const {
  if (GetChain() > secondChain) {
    file << GetChain().ConvertChainToString() << " > " << secondChain.ConvertChainToString();
    file << std::endl;
    file.close();
    return true;
  }
  return false;
}

const bool Manager::PrintComparation2Sub1(std::ofstream& file, std::string filename, const Chain& secondChain) const {
  if (GetChain() < secondChain) {
    file << GetChain().ConvertChainToString() << " < " << secondChain.ConvertChainToString();
    file << std::endl;
    file.close();
    return true;
  }
  return false;
}

