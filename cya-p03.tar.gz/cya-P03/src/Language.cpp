#include "Language.h"

Chain Language::GetIntersection(const Language& language2) {
  std::set<std::string> chainSet2 = language2.GetChain().FromSymbolVecToStringSet(language2.GetChain().GetSymbolsChain());
  std::set<std::string> chainSet1 = GetChain().FromSymbolVecToStringSet(GetChain().GetSymbolsChain());

  std::set<std::string> unionSet;
  std::set_union(chainSet1.begin(), chainSet1.end(), chainSet2.begin(), chainSet2.end(), 
                 std::inserter(unionSet, unionSet.begin()));

  Chain newChainWithSetMember;
  newChainWithSetMember.SetChainSet(unionSet);
  return newChainWithSetMember;  
}



// const bool Chain::operator <(Chain secondChain){















    // Language GetPotency(const int& potency);
    // Language Comparation(const Language& language2);