#include "Chain.h"
#include "Manager.h"

void Chain::FilterChainFromAlphabet(const std::string& input) {
  Symbol symbol;
  std::vector<Symbol> chainAndAlphabet{};
  std::vector<Symbol> chainFinal{};
  std::string chain = "";
  std::string filteringString = "";

  for (int i = 0; i < input.length(); i++){
    //No space so we increase the string
    if (input[i] != ' '){
      filteringString += input[i];
    }
    else{
      symbol.SetSymbol(filteringString);
      chainAndAlphabet.push_back(symbol);
      //If we find a space, then we empty the string
      filteringString = "";
    }
  }
  if (filteringString != ""){
    symbol.SetSymbol(filteringString);
    chainAndAlphabet.push_back(symbol);
  }
  //We make sure that this is not the chain so we push back the alphabet
  std::string finalChainString = chainAndAlphabet[chainAndAlphabet.size() -1].GetSymbol();
  for (int i = 0; i < finalChainString.length(); i++) {
    std::string s(1, finalChainString[i]);
    symbol.SetSymbol(s);
    chainFinal.push_back(symbol);
  }
  SetChain(chainFinal);
}

const std::string Chain::ConvertChainToString() const {
  std::string chain = "";
  for (int i = 0; i < GetSymbolsChain().size(); i++) {
    chain += GetSymbolsChain()[i].GetSymbol();
  }
  return chain;
}

Chain::Chain(const std::string& fileInput) {
  FilterChainFromAlphabet(fileInput);
}


std::set<std::string> Chain::FromSymbolVecToStringSet(const std::vector<Symbol>& symbolVec) const {
  std::string chainInString = ConvertChainToString();
  std::set<std::string> aux;
  aux.insert(chainInString);
  return aux;
}

const bool Chain::operator == (const Chain& secondChain) const {
  if (GetSymbolsChain().size() != secondChain.GetSymbolsChain().size()) {
    return false;
  }
  for (int i = 0; i < GetSymbolsChain().size(); i++) {
    if (GetSymbolsChain()[i] != secondChain.GetSymbolsChain()[i]) {
      return false;
    }
  }
  return true;
}

const bool Chain::operator != (const Chain& secondChain) const {
  if (GetSymbolsChain().size() != secondChain.GetSymbolsChain().size()) {
    return true;
  }
  for (int i = 0; i < GetSymbolsChain().size(); i++) {
    if (GetSymbolsChain()[i] != secondChain.GetSymbolsChain()[i]) {
      return true;
    }
  }
  return false;
}

const bool Chain::operator > (const Chain& secondChain) const {
  Manager selfManager(GetSymbolsChain());
  if (GetSymbolsChain().size() <= secondChain.GetSymbolsChain().size()) {
    return false;
  }
  // std::cout << ConvertChainToString() << " ";
  std::vector<std::string> selfSubchainsInChainType{selfManager.GetSubChains(ConvertChainToString())} ;  
  for (auto subChain : selfSubchainsInChainType) {
    // std::cout << subChain << std::endl;
    if (secondChain.ConvertChainToString() == subChain) {
      return true;
    }
  }
  return false;
}

const bool Chain::operator < (const Chain& secondChain) const {
  Manager secondManager(secondChain.GetSymbolsChain());
  if (GetSymbolsChain().size() >= secondChain.GetSymbolsChain().size()) {
    return false;
  }
  std::vector<std::string> selfSubchainsInChainType{ secondManager.GetSubChains(secondChain.ConvertChainToString()) };
  for (auto subChain : selfSubchainsInChainType) {
    if (subChain == ConvertChainToString()) {
      return true;
    }
  }
return false;
}

const Chain Chain::operator *(const Chain& secondChain) const {
  std::string chain1 = ConvertChainToString();
  std::string chain2 = secondChain.ConvertChainToString();
  std::string concatenatedString = chain1 + chain2;
  Chain chainToReturn(concatenatedString);
  return chainToReturn;
}

const Chain Chain::operator ^(int stoppingPoint) const {
  std::string chain1 = ConvertChainToString();
  std::string concatenatedString = "";
  int i = 0;
  while (i < stoppingPoint) {
    concatenatedString += chain1;
    i++;
  }
  Chain chainToReturn(concatenatedString);
  return chainToReturn;
}

const Chain Chain::operator +(const Chain& chain2) const {
  std::set<std::string> chainSet1 = FromSymbolVecToStringSet(chain2.GetSymbolsChain());
  std::set<std::string> chainSet2 = FromSymbolVecToStringSet(GetSymbolsChain());

  std::set<std::string> unionSet;
  std::set_union(chainSet1.begin(), chainSet1.end(), chainSet2.begin(), chainSet2.end(), 
                 std::inserter(unionSet, unionSet.begin()));
  Chain newChainWithSetMember;
  newChainWithSetMember.SetChainSet(unionSet);
  return newChainWithSetMember;  
}

