#pragma once
#include "Includes.h"

class Symbol {
  public:
    Symbol(){};
    Symbol(std::string symbol) {symbol_ = symbol; };  
    ~Symbol(){};

    const std::string& GetSymbol() const {return symbol_; };
    void SetSymbol(std::string symbol) {symbol_ = symbol; };
    bool IsValid(Symbol symbol);
    const bool operator ==(const Symbol&) const;
    const bool operator !=(const Symbol&) const;
    
  private:
    std::string symbol_ = "";
};




