// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 5: DNA analyzer with a DFA
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 02/11/2021
// Archivo: Definición de la clase DFA, que contiene
// el propio DFA y otras funciones auxiliares como la función FilterSubsequences()

#pragma once
#include "DNASequence.h"

// Our DFA will contain: 
// - acceptation states (int vector)
// - no acceptation states (int vector)
// - all subsequences and filtered sequences (vector of pairs: the .second of the pair contains
// the state of acceptation / no acceptation where the analyzed chain ended.
// - the initial DNA chain to analyze.

class DFA {
 public:
  DFA() {};
  DFA(const DNASequence& initial_sequence) { initial_sequence_ = initial_sequence; };
  DFA(const std::vector<std::pair<DNASequence, int>>& sequences) { all_subsequences_ = sequences; };
  
  //Setters
  void SetInitialSequence(const DNASequence& initial_sequence) { initial_sequence_ = initial_sequence; };
  void SetAllSubsequences(const std::vector<std::pair<DNASequence, int>>& subsequence) { all_subsequences_ = subsequence; };
  void SetAllFilteredSubsequences(const std::vector<std::pair<DNASequence, int>>& subsequence) { filtered_subsequences_ = subsequence; };

  //Getters
  const std::vector<std::pair<DNASequence, int >>& GetAllSubsecuences() const { return all_subsequences_; };
  const std::vector<std::pair<DNASequence, int >>& GetAllFilteredSubsecuences() const { return filtered_subsequences_; };
  const DNASequence& GetInitialSequence() const { return initial_sequence_; };

  //Aux functions
  void EraseDuplicates(std::vector<std::string>& str_vec);
  void WriteAcceptedSequences(std::ofstream& file, std::string filename);

  bool IsAcceptationState(const int& state);

  //Functions to construct and filter all accepted / denied DNA subchains
  void ConstructAllSubsequences();
  void FilterSubsequences();
  void PrintTransitions();

 
 private:
  DNASequence initial_sequence_;

  std::vector<std::pair<DNASequence, int>> all_subsequences_ {};

  std::vector<std::pair<DNASequence, int>> filtered_subsequences_ {};
  
  const std::vector<int> acceptation_states {3, 6};
  const std::vector<int> no_acceptation_states {1, 2, 4, 5}; 

  const std::vector<std::string> states_qi_{"q0", "q1", "q3", "q3", "q4", "q4", "q1", "q0", "q2", "q2", "q5",
                                           "q5", "q6", "q6"};
  const std::vector<std::string> states_qd_{"q1", "q3", "q4", "q3", "q3", "q4", "q4", "q2", "q5", "q6", "q6",
                                           "q5", "q5", "q6"};
  const std::vector<std::string> transition_symbol_{"A", "A", "G,T,C", "A", "A", "G,T,C", "G,T,C", "T", 
                                                   "A,G,C", "T", "T", "A,G,C", "A,G,C", "T"};
};