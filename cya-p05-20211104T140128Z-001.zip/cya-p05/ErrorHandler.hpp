// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 5: DNA analyzer with a DFA
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 02/11/2021
// Archivo: Errorhandler.(For input and help msgs)
#pragma once
struct ErrorHandler {
  static void BadConsoleInputMsg();
  static void NoInputFileMsg();
  static void HelpMessage();
};

void ErrorHandler::BadConsoleInputMsg() {
  std::cout << "Bad input format. Try the following format:  ./p05_dna_sequencer DNA_sequence output.txt" << std::endl;
}

void ErrorHandler::NoInputFileMsg() {
    std::cout << "No input file DNA chain found to analyze. Try the following format: ./p05_dna_sequencer DNA_sequence output.txt" << std::endl;
}

void ErrorHandler::HelpMessage() {
  std::cout << "This is a program to find matching subchains in a DNA chain by the implementation of a given DFA. To use it, type: ./p05_dna_sequencer DNA_sequence output.txt"  << std::endl;
}

