// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 5: DNA analyzer with a DFA
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 02/11/2021
// Archivo: Alphabet implementation

#include "Alphabet.h"

Alphabet::Alphabet(const std::string& alphabet) {
  Symbol aux;
  for (int i = 0; i < alphabet.length(); i++) {
    std::string char_to_str(1, alphabet[i]);
    aux.SetSymbol(char_to_str);
    alphabet_.push_back(aux);
  }
}