// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 5: DNA analyzer with a DFA
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 02/11/2021
// Archivo: Implementación de la clase DFA, que contiene
// el propio DFA y otras funciones auxiliares como la función FilterSubsequences()

#include "DFA.h"

void DFA::EraseDuplicates(std::vector<std::string>& str_vec){
  for (int i = 0; i < str_vec.size(); ++i) {
    for (int j = i + 1; j < str_vec.size(); ) { 
        if (str_vec[i] == str_vec[j]) {
            str_vec.erase(str_vec.begin() + j);
        }
        else j++;
    }
  }
}

void DFA::ConstructAllSubsequences() {
  auto initial_sequence = GetInitialSequence();
  auto all_subchains = initial_sequence.GetSubchains();
  std::vector<std::pair<DNASequence, int>> all_subsequences;
  std::pair<DNASequence, int> dna_with_acceptation_state;
  int state = 0;
  for (int i = 0; i < all_subchains.size(); i++) {
    auto dna_symbol_vector = all_subchains[i].GetSymbolVector();
    for (int j = 0; j < dna_symbol_vector.size(); j++) {
      //not accepted / not starting by A or T
      dna_with_acceptation_state.first = all_subchains[i];
      dna_with_acceptation_state.second = state;
      if (( dna_symbol_vector[0].GetSymbolString() != "A" && dna_symbol_vector[0].GetSymbolString() != "T")
      || (dna_symbol_vector.size() < 2 && dna_symbol_vector[0].GetSymbolString() != "A" &&
      dna_symbol_vector[0].GetSymbolString() != "T") ) {
        state = 0;
        dna_with_acceptation_state.second = state;
        all_subsequences.push_back(dna_with_acceptation_state);
        break;
      }
      //from q0 to q1: (starting with A)
      if (dna_symbol_vector[0].GetSymbolString() == "A") {
        if (dna_symbol_vector.size() < 2) {
          state = 1;
          dna_with_acceptation_state.second = state;
          all_subsequences.push_back(dna_with_acceptation_state);
          break;
        }
        //from q1 to q4
        if (dna_symbol_vector[j].GetSymbolString() == "T" || dna_symbol_vector[j].GetSymbolString() == "C" ||
        dna_symbol_vector[j].GetSymbolString() == "G" ) {
          state = 4;
          dna_with_acceptation_state.second = state;
        }
        //from q4 to q3 (acceptation state)
        if (dna_symbol_vector[j].GetSymbolString() == "A") {
          state = 3;
          dna_with_acceptation_state.second = state;
        }
        //if we reach the end of the chain, we push it back regardless of the state ( we filter the vector afterwards)
        if (j == dna_symbol_vector.size() -1) {
          all_subsequences.push_back(dna_with_acceptation_state);
        }
      }
      //from q0 to q2: (starting with T)
      if (dna_symbol_vector[0].GetSymbolString() == "T") {
        //if size < 2 then we will be stuck at q2 (not acceptation) so we break this iteration directly
        if (dna_symbol_vector.size() < 2) {
          state = 2;
          dna_with_acceptation_state.second = state;
          all_subsequences.push_back(dna_with_acceptation_state);
          break;
        }
        //any symbol other than "T" we go to state 5 (q5) (not acceptation)
        if (dna_symbol_vector[j].GetSymbolString() == "A" || dna_symbol_vector[j].GetSymbolString() == "C" ||
        dna_symbol_vector[j].GetSymbolString() == "G" ) {
          state = 5;
          dna_with_acceptation_state.second = state;
        }
        //if symbol is T, we go to state 6 (acceptation)
        if (dna_symbol_vector[j].GetSymbolString() == "T") {
          state = 6;
          dna_with_acceptation_state.second = state;
        }
        //if we reach the end of the chain, we push it back regardless of the state ( we filter the vector afterwards)
        if (j == dna_symbol_vector.size() -1) {
          all_subsequences.push_back(dna_with_acceptation_state);
        }
      }
    }
  }
  SetAllSubsequences(all_subsequences);
}

bool DFA::IsAcceptationState(const int& state) {
  if (state == 3 || state == 6) {
    return true;
  }
  return false;
}

bool SortBySize(const std::pair<DNASequence, int>& sequences, const std::pair<DNASequence, int> & self_sequences) {
  return (sequences.first.GetSymbolVector().size() < self_sequences.first.GetSymbolVector().size());
}

// This function will be used to clean the results vector. We want the DNA
// sequences sorted from shortest length to longest. Also, we want to erase
// repeated sequences.

void DFA::FilterSubsequences() {
  const auto& sequence_to_filter = GetAllSubsecuences();
  std::vector<std::pair<DNASequence, int>> filtered_subsequences;
  //first filter: we only take sequences accepted
  for (int i = 0; i < sequence_to_filter.size(); i++) {
    if (IsAcceptationState(sequence_to_filter[i].second)) {
      filtered_subsequences.push_back(sequence_to_filter[i]);
    }
  }
  //second filter: sort repeated
  for (int i = 0; i < filtered_subsequences.size(); i++) {
    auto aux = filtered_subsequences[i].first;
    for (int j = 0; j < filtered_subsequences.size(); j++) {
      if (filtered_subsequences[j].first == aux && i != j) {
        filtered_subsequences.erase(filtered_subsequences.begin() + j);
      }
    }
  }
  //third filter: sort by chain length
  std::sort(filtered_subsequences.begin(), filtered_subsequences.end(), SortBySize);
  SetAllFilteredSubsequences(filtered_subsequences);
} 

void DFA::WriteAcceptedSequences(std::ofstream& file, std::string filename) {
  file.open(filename, std::ofstream::app);
  auto filtered_subsequences = GetAllFilteredSubsecuences();
  for (int j = 0; j < filtered_subsequences.size(); j++) {
    for (int i = 0; i < filtered_subsequences[j].first.GetSymbolVector().size(); i++) {
      file << filtered_subsequences[j].first.GetSymbolVector()[i].GetSymbolString();
    }
    file << " " << filtered_subsequences[j].second << std::endl;
  }
  file << std::endl;
}

void DFA::PrintTransitions() {
  std::cout << "qi" << "\t" << "qd" << "\t" << "S" << std::endl << std::endl;
  for (int i = 0; i < states_qi_.size(); i++) {
    std::cout << states_qi_[i] << "\t" << states_qd_[i] << "\t" << transition_symbol_[i] << std::endl; 
  }
}

// Second code example: This one accepts the required chains, but doesn't provide information
// in regards to the states where the chain was accepted / denied
//  void DFA::ConstructAllSubsequences() {
//   const auto& initial_sequence = GetInitialSequence();
//   const auto& initial_sequence_vector = initial_sequence.GetSymbolVector();
//   const int& sequence_length = initial_sequence_vector.size();
//   DNASequence aux_sequence;
//   std::string dna_sequence_str = "";
//   for (int i = 0; i < sequence_length; i++) {
//     for (int j = i + 1; j < sequence_length; j++) {
//       if (initial_sequence_vector[i].GetSymbolString() == initial_sequence_vector[j].GetSymbolString()) {
//         if (initial_sequence_vector[i].GetSymbolString() == "A" ||
//         initial_sequence_vector[i].GetSymbolString() == "T"){
//           for(int k = i; k <= j; k++) {
//             dna_sequence_str += initial_sequence_vector[k].GetSymbolString();
//           }
//           aux_sequence.ConstructFromString(dna_sequence_str);
//           all_subsequences_.push_back(aux_sequence);
//           dna_sequence_str = "";
//         }
//       }
//     }
//   }
// }