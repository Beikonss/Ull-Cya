// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 5: DNA analyzer with a DFA
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 02/11/2021
// Archivo: Definición de la clase DNASequence, que contiene
// funciones auxiliares de análisis de cadenas de ADN.
#include "DNASequence.h"

std::vector<std::string> DNASequence::FromSymbolVecToStringVec(const std::vector<Symbol>& symbol_vec) {
  std::vector<std::string> vector_to_return {};
  for (int i = 0; i < symbol_vec.size(); i++) {
    std::string symbol_string(symbol_vec[i].GetSymbolString());
    vector_to_return.push_back(symbol_string);
  }
  return vector_to_return;
}

std::vector<Symbol> DNASequence::FromStringVecToSymbolVec(const std::vector<std::string>& string_vec) {
  Symbol aux_symbol;
  std::vector<Symbol> vector_to_return{};
  for (int i = 0; i < string_vec.size(); i++) {
    aux_symbol.SetSymbol(string_vec[i]);
    vector_to_return.push_back(aux_symbol);
  }
  return vector_to_return;
}

std::vector<DNASequence> DNASequence::GetSubchains() {
  auto initial_sequence = FromSymbolVecToStringVec(GetSymbolVector());
  std::vector<DNASequence> all_subchains;
  DNASequence to_push;
  std::string dna_chain = "";
  for (int i = 0; i < initial_sequence.size(); i++) {
    dna_chain += initial_sequence[i];
  }
	for (int i = 0; i < dna_chain.length (); i ++) {
		for (int j = 1+i; j < dna_chain.length()+1; j++) {
      to_push.ConstructFromString(dna_chain.substr(i, j - i));
      all_subchains.push_back(to_push);
		}
  }
  return all_subchains;
}

bool DNASequence::operator==(const DNASequence& second_sequence) {
  auto self_symbol_vec = GetSymbolVector();
  auto second_sequence_symbol_vec = second_sequence.GetSymbolVector();
  if (self_symbol_vec.size() != second_sequence_symbol_vec.size()) {
    return false;
  }
  for (int i = 0; i < self_symbol_vec.size(); i++) {
    if (self_symbol_vec[i].GetSymbolString() != second_sequence_symbol_vec[i].GetSymbolString()) {
      return false;
    }
  }
  return true;
}

bool DNASequence::IsValid(const Alphabet& alphabet) {
  auto sequence = GetSymbolVector();
  bool is_valid = false;
  for (auto symbol : sequence) {
    for (auto alphabet_symbol : alphabet.GetAlphabet()) {
      if (symbol.GetSymbolString() == alphabet_symbol.GetSymbolString()) {
        is_valid = true;
      }
    }
    if (is_valid == false) {
      return is_valid;
    }
    is_valid = false;
  }
  return true;
}

bool DNASequence::IsValid(const std::vector<std::string>& alphabet) {
  auto sequence = GetSymbolVector();
  auto tal = FromStringVecToSymbolVec(alphabet);
  bool is_valid = false;
  for (auto symbol : sequence) {
        // std::cout << symbol.GetSymbolString();
    for (auto alphabet_symbol : tal) {
      // std::cout << alphabet_symbol.GetSymbolString();
      if (symbol.GetSymbolString() == alphabet_symbol.GetSymbolString()) {
        is_valid = true;
      }
    }
    if (is_valid == false) {
      return is_valid;
    }
    is_valid = false;
  }
  return true;
}

// Constructor auxiliar function
void DNASequence::ConstructFromString(const std::string& string) {
  Symbol aux;
  std::vector<Symbol> new_sequence{};
  for (int i = 0; i < string.length(); i++) {
    std::string new_symbol(1, string[i]);
    aux.SetSymbol(new_symbol);
    new_sequence.push_back(aux);
  }
  SetSequence(new_sequence);
}
