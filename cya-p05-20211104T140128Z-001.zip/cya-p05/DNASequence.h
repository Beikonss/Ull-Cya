// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 5: DNA analyzer with a DFA
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 02/11/2021
// Archivo: Declaración de la clase DNASequence, que contiene
// funciones auxiliares de análisis de cadenas de ADN.

#pragma once
#include <iostream>
#include <vector>
#include <string>
#include <bits/stdc++.h>

#include "Alphabet.h"

class DNASequence {
 public:
  DNASequence() {};
  DNASequence(const std::vector<Symbol>& sequence) { sequence_ = sequence; };
  DNASequence(const std::string& sequence) { ConstructFromString(sequence); };

  // Getter
  const std::vector<Symbol>& GetSymbolVector() const { return sequence_; };

  // Setters (overloaded)
  void SetSequence(const DNASequence& sequence) { sequence_ = sequence.GetSymbolVector(); };
  void SetSequence(const std::vector<Symbol>& sequence) { sequence_ = sequence; };

  void ConstructFromString(const std::string& string_sequence);

  // Auxiliar functions
  std::vector<std::string> FromSymbolVecToStringVec(const std::vector<Symbol>& symbolVec);
  std::vector<Symbol> FromStringVecToSymbolVec(const std::vector<std::string>& symbolVec);
  
  //Most important function -> With this we get all subchains that will be analyzed by the DFA.
  std::vector<DNASequence> GetSubchains();

  bool IsValid(const Alphabet& alphabet);
  bool IsValid(const std::vector<std::string>& alphabet);

  bool operator==(const DNASequence& second_sequence);

 private: 
  std::vector<Symbol> sequence_;
};