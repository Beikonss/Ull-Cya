// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 5: DNA analyzer with a DFA
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 02/11/2021
// Archivo: Cliente

#include "DFA.h"
#include "ErrorHandler.hpp"
#include <bits/stdc++.h>

int main(int argc, char* argv[]) {
  std::string helpCheck = argv[1];
  if (helpCheck == "--help") {
    ErrorHandler::HelpMessage();
    return 0;
  }
  if (argc == 3) {
    std::string dna_sequence = argv[1];
    if (argv[2] == ""){
      ErrorHandler::NoInputFileMsg();
      return 0;
    }
    std::ofstream outputStream;
    std::string outputFile = argv[2];
    Alphabet input_alphabet("ATGC");
    DNASequence input_sequence(dna_sequence);
    if (!input_sequence.IsValid(input_alphabet)) {
      std::cout << "DNA chain not valid. It has to match the following alphabet: {A, T, G, C}" << std::endl;
      return 0;
    }
    DFA constructed_dfa(input_sequence);
    constructed_dfa.ConstructAllSubsequences();
    constructed_dfa.FilterSubsequences();
    constructed_dfa.WriteAcceptedSequences(outputStream, outputFile);
    constructed_dfa.PrintTransitions();
  }
  else {
    ErrorHandler::BadConsoleInputMsg();
  }
  return 0;
}