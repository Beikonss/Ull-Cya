// Universidad de La Laguna
// Escuela Superior de Ingenier ́ıa y Tecnolog ́ıa
// Grado en Ingenier ́ıa Inform ́atica
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 3: Operaciones con cadenas y lenguages
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P03-ClienteStrings.cc: programa cliente.
// Contiene la función main del proyecto que usa las clases Manager, ErrorHandler y
// Language (para la unión de sets ordenados)

#include "Manager.h"
#include "ErrorHandler.hpp"
#include "Language.h"

int main(int argc, char* argv[]){
    if (argc == 4){
      //Streams / Classes instantiations
      std::ifstream file(argv[1]);
      std::ofstream outputStream;
      std::string outputFile = argv[2];
      std::string line; 

      int opcode = atoi(argv[3]);
      if (!file){
        ErrorHandler::NoInputFileMsg();
      }
      ErrorHandler::WrongOpcodeMsg(opcode);
      if (file.is_open()){
        ErrorHandler::PrintOpcode(opcode, argv[1]);
        int lineIndex = 0;
        std::string newChainOpcode7 = " ";
        if (opcode == 7) {
          std::cout << "Diga la cadena con la que quiere comparar: " << std::endl;
          std::cin >> newChainOpcode7;
        }
        int power = 0;
        if (opcode == 8) {
          std::cout << "Diga la potencia: " << std::endl;
          std::cin >> power;
        }
        std::string newChain = " ";
        if (opcode == 6) {
          std::cout << "Diga la cadena con la que quiere comparar: " << std::endl;
          std::cin >> newChain;
        }

    //We tell the user which opcode they chose and what it does
    //   ErrorHandler::PrintOpcode(opcode, argv[1]);
        while (getline(file,line)) {
          lineIndex++;
          if (line == ""){
            ErrorHandler::PrintVoid(outputStream, outputFile, lineIndex);
            continue;
          }
          Manager manager(line);
          manager.GetAlphabetFromChain(lineIndex);
          if (ErrorHandler::IndivisibleSymbolWarningMsg(manager, lineIndex)) {
            continue;
          }
          if (ErrorHandler::ChainCharacterDoesntMatchToAlphabet(manager, lineIndex)) {
            continue;
          }
          
          printf(Green);
          if (opcode < 6) {
            std::cout << "Line [" << lineIndex << "]: Operation completed" << std::endl;
          }

          Chain secondChainForOpcode6(newChain);
          Chain secondChainForOpcode7(newChainOpcode7);
          Language language1(manager.GetChain());
          Language language2(secondChainForOpcode7);
          auto languageUnion = language1 + language2;
          
          switch(opcode){            
            case(1):
              manager.PrintLength(outputStream, outputFile);
              break;
            case(2):
              manager.PrintReversedChain(outputStream, outputFile);
              break;
            case(3):
              manager.PrintPrefixes(outputStream, outputFile);
              break;
            case(4):
              manager.PrintSufixes(outputStream, outputFile);
              break;
            case(5):
              manager.PrintSubChains(outputStream, outputFile);
              break;
            case(6):
              if (manager.PrintComparationEqual(outputStream, outputFile, secondChainForOpcode6) == true) {
                std::cout << "Line [" << lineIndex << "]: Operation completed" << std::endl;
                break;
              }
              if (manager.PrintComparation1Sub2(outputStream, outputFile, secondChainForOpcode6) == true) {
                std::cout << "Line [" << lineIndex << "]: Operation completed" << std::endl;
                break;
              }
              if (manager.PrintComparation2Sub1(outputStream, outputFile, secondChainForOpcode6) == true) {
                std::cout << "Line [" << lineIndex << "]: Operation completed" << std::endl;
                break;
              }
              (manager.PrintComparationNotEqual(outputStream, outputFile, secondChainForOpcode6));
              std::cout << "Line [" << lineIndex << "]: Operation completed" << std::endl;
              break;
            case(7):
              manager.PrintConcatenation(outputStream, outputFile, secondChainForOpcode7);
              std::cout << "Line [" << lineIndex << "]: Operation completed" << std::endl;
              std::cout << "The union from ordered sets is: ";
              for (auto unionChar : languageUnion.GetChainSet()) {
                std::cout << unionChar;
              }
              std::cout << std::endl;
              break;
            case(8):
              manager.PrintPower(outputStream, outputFile, manager.GetChain(), power);
              std::cout << "Line [" << lineIndex << "]: Operation completed" << std::endl;
              break;
              
          }
          printf(White);
        }
      }
    }
    else {
      ErrorHandler::BadConsoleInputMsg();
    }
}