// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 3: Operaciones con cadenas y lenguajes
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P03-Chain.h: header de la clase cadena
// que contiene las cadenas

#pragma once
#include "Includes.h"
#include "Symbol.h"

class Chain {
  public:
    Chain(){};
    Chain(std::vector<Symbol> chain) {chain_ = chain; };
    Chain(const std::string& fileInput);
    
    const std::vector<Symbol>& GetSymbolsChain() const {return chain_; };
    std::unordered_set<std::string> GetChainSet() {return chainSet_; };
    void SetChain(std::vector<Symbol> chain) {chain_ = chain; };
    void SetChainSet(std::unordered_set<std::string> chainSet) {chainSet_ = chainSet; };
    void FilterChainFromAlphabet(const std::string& fileInput);
    std::vector<Chain> FromStringVecToChainVec(const std::vector<std::string>& stringVec) const;
    const std::string ConvertChainToString() const;
    std::unordered_set<std::string> FromSymbolVecToStringSet(const std::vector<Symbol>& symbolVec) const;

    const bool operator == (const Chain&) const;
    const bool operator != (const Chain&) const;
    const bool operator > (const Chain&) const;
    const bool operator < (const Chain&) const;
    const Chain operator *(const Chain&) const;
    const Chain operator ^(int n) const;
    const Chain operator +(const Chain&) const;

    friend std::ostream &operator<<(std::ostream &output, Chain chain ) {
      output << chain.ConvertChainToString();
      return output;
    }
    
    friend std::istream &operator>>(std::istream &input, Chain chain ) {
      std::string stringInput;
      input >> stringInput;
      chain.FilterChainFromAlphabet(stringInput);
      return input;
    }

  private:
    std::vector<Symbol> chain_{};
    std::unordered_set<std::string> chainSet_;
};

