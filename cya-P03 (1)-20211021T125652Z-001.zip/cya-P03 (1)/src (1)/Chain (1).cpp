// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 3: Operaciones con cadenas y lenguajes
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P03-Chain.cpp: definiciones de los método
// de la clase chain que contiene las cadenas

#include "Chain.h"
#include "Manager.h"

void Chain::FilterChainFromAlphabet(const std::string& input) {
  Symbol symbol;
  std::vector<Symbol> chainAndAlphabet{};
  std::vector<Symbol> chainFinal{};
  std::string chain = "";
  std::string filteringString = "";

  for (int i = 0; i < input.length(); i++){
    //No space so we increase the string
    if (input[i] != ' '){
      filteringString += input[i];
    }
    else{
      symbol.SetSymbol(filteringString);
      chainAndAlphabet.push_back(symbol);
      //If we find a space, then we empty the string
      filteringString = "";
    }
  }
  if (filteringString != ""){
    symbol.SetSymbol(filteringString);
    chainAndAlphabet.push_back(symbol);
  }
  //We make sure that this is not the chain so we push back the alphabet
  std::string finalChainString = chainAndAlphabet[chainAndAlphabet.size() -1].GetSymbol();
  for (int i = 0; i < finalChainString.length(); i++) {
    std::string s(1, finalChainString[i]);
    symbol.SetSymbol(s);
    chainFinal.push_back(symbol);
  }
  SetChain(chainFinal);
}

const std::string Chain::ConvertChainToString() const {
  std::string chain = "";
  for (int i = 0; i < GetSymbolsChain().size(); i++) {
    chain += GetSymbolsChain()[i].GetSymbol();
  }
  return chain;
}

Chain::Chain(const std::string& fileInput) {
  FilterChainFromAlphabet(fileInput);
}

std::unordered_set<std::string> Chain::FromSymbolVecToStringSet(const std::vector<Symbol>& symbolVec) const {
  std::string chainInString = ConvertChainToString();
  std::unordered_set<std::string> aux;
  aux.insert(chainInString);
  return aux;
}

const bool Chain::operator == (const Chain& secondChain) const {
    //2 chains are equal if size is equal and all symbols are the same and in the same order:
  //Size check
  if (GetSymbolsChain().size() != secondChain.GetSymbolsChain().size()) {
    return false;
  }
  //Order check
  for (int i = 0; i < GetSymbolsChain().size(); i++) {
    if (GetSymbolsChain()[i] != secondChain.GetSymbolsChain()[i]) {
      return false;
    }
  }
  return true;
}

const bool Chain::operator != (const Chain& secondChain) const {
  //2 chains are equal if size is equal and all symbols are the same and in the same order:
  //Size check
  if (GetSymbolsChain().size() != secondChain.GetSymbolsChain().size()) {
    return true;
  }
  //Order check
  for (int i = 0; i < GetSymbolsChain().size(); i++) {
    if (GetSymbolsChain()[i] != secondChain.GetSymbolsChain()[i]) {
      return true;
    }
  }
  return false;
}

const bool Chain::operator > (const Chain& secondChain) const {
  Manager selfManager(GetSymbolsChain());
  //2 is subchain of 1, so if 1 is smaller than 2 we return false directly
  if (GetSymbolsChain().size() <= secondChain.GetSymbolsChain().size()) {
    return false;
  }
  
  std::vector<std::string> selfSubchainsInChainType{selfManager.GetSubChains(ConvertChainToString())} ;  
  for (auto subChain : selfSubchainsInChainType) {
    if (secondChain.ConvertChainToString() == subChain) {
      return true;
    }
  }
  return false;
}

const bool Chain::operator < (const Chain& secondChain) const {
  Manager secondManager(secondChain.GetSymbolsChain());
  //1 is subchain of 2, so if 2 is smaller than 1 we return false directly
  if (GetSymbolsChain().size() >= secondChain.GetSymbolsChain().size()) {
    return false;
  }
  std::vector<std::string> selfSubchainsInChainType{ secondManager.GetSubChains(secondChain.ConvertChainToString()) };
  for (auto subChain : selfSubchainsInChainType) {
    if (subChain == ConvertChainToString()) {
      return true;
    }
  }
return false;
}

const Chain Chain::operator *(const Chain& secondChain) const {
  //Simple concatenation
  std::string chain1 = ConvertChainToString();
  std::string chain2 = secondChain.ConvertChainToString();
  std::string concatenatedString = chain1 + chain2;
  Chain chainToReturn(concatenatedString);
  return chainToReturn;
}

const Chain Chain::operator ^(int stoppingPoint) const {
  //Power of string
  std::string chain1 = ConvertChainToString();
  std::string concatenatedString = "";
  int i = 0;
  while (i < stoppingPoint) {
    concatenatedString += chain1;
    i++;
  }
  Chain chainToReturn(concatenatedString);
  return chainToReturn;
}