// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Prática 3: Operaciones con cadenas y lenguajes
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P03-Language.cpp
// Contiene las definiciones de los métodos de la clase Language --> contenedores de cadenas y sets (strings)
// sobrecarga de operador + y union

#include "Language.h"

Chain Language::GetUnion(const Language& language2) {
  auto chainSet1 = language2.GetChain().FromSymbolVecToStringSet(language2.GetChain().GetSymbolsChain());
  auto chainSet2 = GetChain().FromSymbolVecToStringSet(GetChain().GetSymbolsChain());

  std::unordered_set<std::string> unionSet;
  std::set_union(chainSet1.begin(), chainSet1.end(), chainSet2.begin(), chainSet2.end(), 
                 std::inserter(unionSet, unionSet.begin()));

  Chain newChainWithSetMember;
  newChainWithSetMember.SetChainSet(unionSet);
  return newChainWithSetMember;  
}

const Chain Language::operator+(const Language& language2) {
  return (GetUnion(language2));
}