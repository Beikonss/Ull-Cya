// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 3: Operaciones con cadenas y lenguajes
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P02-String.cpp: programa cliente.
// Contiene la clase Symbol: Contiene las declaraciones de la clase
// Symbol, que son principalmente sobrecarga de operadores



#pragma once
#include "Includes.h"

class Symbol {
  public:
    Symbol(){};
    Symbol(std::string symbol) {symbol_ = symbol; };  
    ~Symbol(){};

    const std::string& GetSymbol() const {return symbol_; };
    void SetSymbol(std::string symbol) {symbol_ = symbol; };
    bool IsValid(Symbol symbol);
    const bool operator ==(const Symbol&) const;
    const bool operator !=(const Symbol&) const;
    
  private:
    std::string symbol_ = "";
};




