// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 3: Operaciones con cadenas y lenguajes
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P03-ErrorHandler.cc
// Contiene la clase ErrorHandler --> para error handling

#pragma once
#include "Includes.h"
#include "Manager.h"

struct ErrorHandler : Manager {
    static bool NoChainFound(Manager stringToCheck);
    static bool SubchainFoundInAlphabet(Manager stringToCheck, int lineIndex);
    static void BadConsoleInputMsg();
    static void NoInputFileMsg();
    static bool HasDuplicated(std::vector<Symbol> strVec);
    static bool ChainCharacterDoesntMatchToAlphabet(Manager stringToCheck, const int& lineIndex);
    static void PrintOpcode(const int opcode, const std::string& file);
    static bool TooLongChainWarning(Manager stringToCheck);
    static void WrongOpcodeMsg(const int opcode);
    static void FoundVoidSymbolErrorMsg();
    static void PrintVoid(std::ofstream& file, std::string filename, int lineIndex);
    static bool IndivisibleSymbolWarningMsg(Manager stringToCheck, const int lineIndex);

};

bool ErrorHandler::IndivisibleSymbolWarningMsg(Manager toCheck, const int lineIndex) {
  if (toCheck.IsIndivisibleSymbolFoundDividedInChain()) {
    printf(Red);
    std::cout << "Line[" << lineIndex << "] " << "Warning: an indivisible symbol was found divided in the chain. Skipping this line . . ." << std::endl;
    printf(Green);
    return true;
  }
  return false;
}

void ErrorHandler::WrongOpcodeMsg(const int opcode) {
  if (opcode > 8 || opcode <= 0){
    std::cout << "Wrong opcode introduced . . . Try an option from 1 - 8" << std::endl;
    exit(EXIT_FAILURE);
  }
}

void ErrorHandler::BadConsoleInputMsg() {
    std::cout << "Bad input format. Try the following format: ./p02_strings filein.txt fileout.txt opcode" << std::endl;
    exit(EXIT_FAILURE);
}

void ErrorHandler::NoInputFileMsg() {
    std::cout << "No input file (filein) found. Try the following format: ./p02_strings filein.txt fileout.txt opcode" << std::endl;
    exit(EXIT_FAILURE);
}

bool ErrorHandler::TooLongChainWarning(Manager stringToCheck) {
    int length = stringToCheck.GetLength();
    std::string optionChosen;
    if (length > 7){
        std::cout << std::endl << "Warning: length of chain is too long. This program is not optimized for long chains." << std::endl <<
        "Are you sure you want to continue? (This might hang the process) "
        << "Write: 'yes' to continue" << std::endl;
        std::cin >> optionChosen;
        if (optionChosen != "yes") {
            return false;
        }
        return true;
    }
    return true;
}

bool ErrorHandler::ChainCharacterDoesntMatchToAlphabet(Manager stringToCheck, const int& lineIndex) {
  std::string chain = stringToCheck.GetChain().ConvertChainToString();
  std::vector<Symbol> alphabet = stringToCheck.GetAlphabet().GetAlphabet();
  std::vector<char> toCompare{};
  printf(Red);
  for (int i = 0; i<alphabet.size(); i++) {
    for (int j = 0; j<alphabet[i].GetSymbol().length(); j++) {
    toCompare.push_back(alphabet[i].GetSymbol()[j]);
    }
  }

  for (int k = 0; k < chain.length(); k++) {
    for (int l = 0; l < toCompare.size(); l++) {
      if (chain[k] == toCompare[l]){
        break;
      }
      if (chain[k] != toCompare[l] && l == toCompare.size() - 1) {
        std::cout <<  "Line[" << lineIndex << "] " << "Warning: " << chain[k] << " doesn't belong to the alphabet ..." <<  " skipping this line...(Maybe you forgot to input a chain?)" << std::endl;
        return true;
      }
    }
  }
  printf(Green);
  return false;
}

bool ErrorHandler::HasDuplicated(std::vector<Symbol> strVec){
  for (int i = 0; i < strVec.size(); ++i) {
    for (int j = i + 1; j < strVec.size(); ) { 
      if (strVec[i] == strVec[j]) {
            return true;
      }
      else ++j;
    }
  }
  return false;
}

bool ErrorHandler::SubchainFoundInAlphabet(Manager stringToCheck, int lineIndex){
  auto alphabet = stringToCheck.GetAlphabet().GetAlphabet();
  if (HasDuplicated(alphabet)) {
    std::cout << "Line[" << lineIndex << ']' << " " << "Warning: some alphabet members are duplicated" << std::endl;
  }
  return true;
}

void ErrorHandler::PrintVoid(std::ofstream& file, std::string filename, int lineIndex) {
  std::string msg = "&";
  std::cout << "Line [" << lineIndex << "]: " << "Empty line. {&}" << std::endl;
  file.open(filename, std::ofstream::app);
  file << msg << std::endl;
  file.close();
}

void ErrorHandler::PrintOpcode(const int opcode, const std::string& file) {
  printf(Blue);
  std::cout << std::endl;
  switch(opcode){
    case(1):
      std::cout << "[Opcode 1]: Get the size of the chain selected. Writing to file " << file << " . . ."
      << std::endl;
      break;
    case(2):
      std::cout << "[Opcode 2]: Get the reverse of the chain selected. Writing to file " << file << " . . ."
      << std::endl;
      break;
    case(3):
      std::cout << "[Opcode 3]: Get the prefixes of the chain selected. Writing to file " << file << " . . ."
      << std::endl;
      break;
    case(4):
      std::cout << "[Opcode 4]: Get the sufixes of the chain selected. Writing to file " << file << " . . ."
      << std::endl;
      break;
    case(5):
      std::cout << "[Opcode 5]: Get the subchains of the chain selected. Writing to file " << file << " . . ."
      << std::endl;
      break;
  }
  printf(Green);
}
