// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Prática 3: Operaciones con cadenas y lenguajes
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P03-Language.h
// Contiene la clase Language --> contenedores de cadenas y sets (strings)

#include "Includes.h"
#include "Chain.h"

class Language {
  public:
    Language(){};
    Language(const Chain& chain) {chain_ = chain; };
    Language(const Language& language) {chainSet_ = language.chainSet_; };

    std::unordered_set<std::string> GetLanguageSet() const {return chainSet_; } ;
    const Chain GetChain() const {return chain_; };
    void SetLanguage(const Chain& chain) {chain_ = chain; };
    void SetLanguageSet(const std::unordered_set<std::string>& chainSet) {chainSet_ = chainSet; };

    Chain GetUnion(const Language& language2);
    Language GetPotency(const int& potency);
    const Chain operator +(const Language& secondLanguage);

  private:
    Chain chain_;
    std::unordered_set<std::string> chainSet_;

};