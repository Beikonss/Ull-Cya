// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Práctica 3: Operaciones con cadenas y lenguajes
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P03-Alphabet.h: header de la clase alphabet que contiene
// los métodos para gestionar los alfabetos

#pragma once
#include "Includes.h"
#include "Symbol.h"

class Alphabet {
  public:
    //Constructors
    Alphabet(){};
    Alphabet(const std::string& fileInput);
    Alphabet(std::vector<Symbol> alphabet) {alphabet_ = alphabet; };

    //Getters/Setters
    const std::vector<Symbol>& GetAlphabet() const {return alphabet_; };
    void SetAlphabet(const std::vector<Symbol>& alphabet) {alphabet_ = alphabet; };
    //Method for setters / constructor
    void FilterChainFromAlphabet(const std::string& fileInput);

    //Operators overloads
    friend std::ostream &operator<<(std::ostream &output, Alphabet alphabet ) {
      auto symbolAlphabet = alphabet.GetAlphabet();
      for (auto& symbol : symbolAlphabet) {
        output << symbol.GetSymbol();
      }
      return output;
    }
    
    friend std::istream &operator>>(std::istream &input, Alphabet alphabet ) {
      std::string stringInput;
      input >> stringInput;
      alphabet.FilterChainFromAlphabet(stringInput);
      return input;
    }

  private:
    std::vector<Symbol> alphabet_{};
};