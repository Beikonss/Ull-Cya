// Universidad de La Laguna
// Escuela Superior de Ingeniería y Tecnología
// Grado en Ingeniería Informática
// Asignatura: Computabilidad y Algoritmia
// Curso: 2º
// Prática 2: Símbolos, alfabetos y cadenas
// Autor: Francisco Javier Viña
// Correo: alu0101217536@ull.edu.es
// Fecha: 21/10/2021
// Archivo cya-P02-String.cpp
// Contiene la clase Symbol: Contiene las definiciones de la clase
// Symbol, que son principalmente sobrecarga de operadores


#include "Symbol.h"

bool Symbol::IsValid(Symbol symbol) {
  if (symbol.GetSymbol() == "&") {
    return false;
  }
  return true;
}

const bool Symbol::operator ==(const Symbol& symbolToCompare) const {
  if (GetSymbol() == symbolToCompare.GetSymbol()) {
    return true;
  }
  return false;
}

const bool Symbol::operator != (const Symbol& symbolToCompare) const {
  if (GetSymbol() == symbolToCompare.GetSymbol()) {
    return false;
  }
  return true;
}

std::ostream& operator<<(std::ostream& os, Symbol symbol) {
  os << symbol.GetSymbol();
  return os;
}